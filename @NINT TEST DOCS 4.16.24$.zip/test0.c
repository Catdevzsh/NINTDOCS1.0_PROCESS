#include <SDL2/SDL.h>
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Initialize SDL - SDL_Init returns 0 on success
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "Could not initialize SDL: %s\n", SDL_GetError());
        return 1;
    }

    // Create an SDL window: Title, x position, y position, width, height, window flags
    SDL_Window* window = SDL_CreateWindow("SDL2 Window",
                                          SDL_WINDOWPOS_CENTERED, // Centers the window
                                          SDL_WINDOWPOS_CENTERED, // Centers the window
                                          800, 600,               // Width and height in pixels
                                          SDL_WINDOW_SHOWN);      // Window is visible
    if (!window) {
        fprintf(stderr, "Could not create window: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    // Create a renderer that will draw to the window, -1 specifies that we want to load the first
    // compatible driver
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        fprintf(stderr, "Could not create renderer: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    // Event handling
    SDL_Event e;
    int quit = 0;

    while (!quit) {
        // Handle events on queue
        while (SDL_PollEvent(&e) != 0) {
            // User requests quit
            if (e.type == SDL_QUIT) {
                quit = 1;
            }
        }

        // Set draw color to blue (Red, Green, Blue, Alpha)
        SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
        // Clear the window to the draw color
        SDL_RenderClear(renderer);

        // Set the draw color to red for the rectangle
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);  // Red color

        // Define the rectangle we want to draw: x position, y position, width, height
        SDL_Rect fillRect = { 200, 150, 400, 300 };
        SDL_RenderFillRect(renderer, &fillRect);  // Draw the rectangle

        // Display what has been drawn
        SDL_RenderPresent(renderer);
    } 
    return 0;
}
