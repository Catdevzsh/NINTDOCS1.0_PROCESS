#include <stdio.h>

int main() {
    // Print "Hello, cat!" to the stdout
    printf("Hello, cat!\n");
    return 0;
}
