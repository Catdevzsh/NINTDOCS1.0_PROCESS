#include <SDL2/SDL.h>
#include <stdio.h>

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600
#define DVD_WIDTH 40
#define DVD_HEIGHT 20

int main(int argc, char *argv[]) {
    SDL_Window *window;
    SDL_Renderer *renderer;
    SDL_Event event;
    int dx = 5; // Horizontal velocity
    int dy = 5; // Vertical velocity
    int x = WINDOW_WIDTH / 2 - DVD_WIDTH / 2; // Initial x position
    int y = WINDOW_HEIGHT / 2 - DVD_HEIGHT / 2; // Initial y position

    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL initialization failed: %s\n", SDL_GetError());
        return 1;
    }

    // Create a window
    window = SDL_CreateWindow("DVD Logo", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE);
    if (!window) {
        printf("Failed to create window: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    // Disable window maximize button
    SDL_SetWindowResizable(window, SDL_FALSE);

    // Create a renderer
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) {
        printf("Failed to create renderer: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    // Main loop
    int quit = 0;
    while (!quit) {
        // Event handling
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                quit = 1;
            }
        }

        // Update position
        x += dx;
        y += dy;

        // Bounce off edges
        if (x <= 0 || x >= WINDOW_WIDTH - DVD_WIDTH) {
            dx = -dx; // Reverse horizontal velocity
        }
        if (y <= 0 || y >= WINDOW_HEIGHT - DVD_HEIGHT) {
            dy = -dy; // Reverse vertical velocity
        }

        // Clear the renderer
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        // Render ASCII DVD logo
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_Rect rect = { x, y, DVD_WIDTH, DVD_HEIGHT };
        SDL_RenderFillRect(renderer, &rect);

        // Present the renderer
        SDL_RenderPresent(renderer);
    }

    // Cleanup
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    
    return 0;
}
